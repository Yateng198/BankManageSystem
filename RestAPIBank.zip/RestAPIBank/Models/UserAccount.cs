﻿namespace RestAPITesting.Models
{
    public class UserAccount
    {
        public int userId { get; set; }
        public long CardNumber { get; set; }
        public double Balance { get; set; }
    }
}
