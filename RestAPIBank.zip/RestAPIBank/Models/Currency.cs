﻿namespace RestAPIBank.Models
{
    public class Currency
    {
        public string Date { get; set; }
        public double CAD { get; set; }
        public double USD { get; set; }
        public double EUR { get; set; }
        public double CNY { get; set; }
        public double JPY { get; set; }
        public double AUD { get; set; }
        public double MXN { get; set; }

    }
}
